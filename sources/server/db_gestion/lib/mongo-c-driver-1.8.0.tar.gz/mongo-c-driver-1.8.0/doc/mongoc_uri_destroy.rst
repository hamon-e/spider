:man_page: mongoc_uri_destroy

mongoc_uri_destroy()
====================

Synopsis
--------

.. code-block:: c

  void
  mongoc_uri_destroy (mongoc_uri_t *uri);

Parameters
----------

* ``uri``: A :symbol:`mongoc_uri_t`.

Description
-----------

Frees all resources associated with a uri.

