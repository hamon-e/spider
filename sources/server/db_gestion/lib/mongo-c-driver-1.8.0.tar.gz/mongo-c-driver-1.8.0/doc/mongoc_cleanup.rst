:man_page: mongoc_cleanup

mongoc_cleanup()
================

Synopsis
--------

.. code-block:: c

  void
  mongoc_cleanup (void);

Description
-----------

.. include:: includes/init_cleanup.txt
