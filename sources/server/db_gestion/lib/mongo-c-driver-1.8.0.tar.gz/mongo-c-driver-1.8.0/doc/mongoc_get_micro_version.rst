:man_page: mongoc_get_micro_version

mongoc_get_micro_version()
==========================

Synopsis
--------

.. code-block:: c

  int
  mongoc_get_micro_version (void);

Returns
-------

The value of ``MONGOC_MICRO_VERSION`` when libmongoc was compiled.

